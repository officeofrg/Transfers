# Title : WOS NECA Monthly Activity
# Date  : 25th May 2020
# Created by : Chetan Rokade (cr0664)
# Version : 1.0

# Prequisites :
#  1) Local m/c should have all diresctories as per MnP like C:\BLSDATA\IC_BIP\Current\Zipped
#  2) Installations required : Python 3.7 and above, paramiko module.
#  3) Please add TEMP path in your env variables of local m/c if not present
#  4) Please provide PPK_Path including .ppk file-name as per your local m/c
#
#  NOTES :
#    Execution Time: Between 1 AM CT and 5 AM CT on or before 4th day of every month.
#    Please run this script after files are extracted using "Process_Email_NECA_Bip_Data.bat"

import paramiko
import sys
import os
import time
import shutil
from os import environ

NECA_DIR = 'C:\\BLSDATA\\IC_BIP\\Current\\Zipped\\NECA'
PPK_Path = input("Please provide your .ppk file full path : \n")


ATT_ID = input("Please provide your ATT-ID : \n")


def find_files(filenames, search_path):
    result = []

    for filename in filenames:
        for files in os.listdir(search_path):
            if filename in files:
                result.append(os.path.join(filename))

    return result


# Function call find_files()
fileList = find_files(["VHTM012.TXT", "VHTM021.TXT", "VHTM022.TXT", "VHTM026.TXT", "VHTM029.TXT", "VHTM030.TXT", "VHTM036.TXT", "VHTM045.TXT", "VHTM053.TXT",
                       "VHTM055.TXT", "VHTM060.TXT", "VHTM062.TXT", "VHTN012.TXT", "VHTN021.TXT", "VHTN022.TXT", "VHTN029.TXT", "VHTN026.TXT", "VHTN030.TXT",
                       "VHTN036.TXT", "VHTN045.TXT", "VHTN053.TXT", "VHTN055.TXT", "VHTN060.TXT", "VHTN062.TXT"],
                      "C:\\BLSDATA\\IC_BIP\\Current")

print("Total files found out of 24 required files -->>")
print(fileList.__len__())
print("Please find list of files correctly found in extracted files -->> ")
print(fileList)

fCount = fileList.__len__()

if fCount == 24:
    if os.path.exists(NECA_DIR):
        shutil.rmtree(NECA_DIR)
        os.makedirs(NECA_DIR)
    else:
        os.makedirs(NECA_DIR)

    for file in fileList:
        os.chdir("C:\\BLSDATA\\IC_BIP\\Current\\")
        shutil.copy(file, NECA_DIR)

    shutil.make_archive(
        NECA_DIR, 'zip', 'C:\\BLSDATA\\IC_BIP\\Current\\Zipped\\NECA')

    ssh = paramiko.SSHClient()
    ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    ssh.connect(hostname='130.5.126.18', username=ATT_ID,
                key_filename=PPK_Path, port=22)

    sftp_client = ssh.open_sftp()
    # sftp_client.chdir("/opt/app/p1c1m1054/NECA4/")
    # print(sftp_client.getcwd())
    print("Copying NECA.zip on 130.5.126.18")
    sftp_client.put('C:\\BLSDATA\\IC_BIP\\Current\\Zipped\\NECA.zip',
                    '/opt/app/p1c1m1054/NECA4/NECA.zip')

    sftp_client.close()
    ssh.exec_command('chmod 777 /opt/app/p1c1m1054/NECA4/NECA.zip')
    print("NECA.zip copied successfully on 130.5.126.18 under /opt/app/p1c1m1054/NECA4")

    ssh.close()

    # stdin, stdout, stderr = ssh.exec_command('whoami')
    # print(stdout.readlines())
    # print(stderr.readlines())

    # *********************  main.ksh *******************************

    # print("Runnning main.ksh")
    # hostname = '130.5.126.18'
    # myuser = 'cr0664'
    # mySSHK = 'C:\\Users\\chetanro\\OneDrive - AMDOCS\\Backup Folders\\Documents\\EMAS\\Scripts\\cr0664.ppk'

    # sshcon = paramiko.SSHClient()  # will create the object
    # sshcon.set_missing_host_key_policy(
    #     paramiko.AutoAddPolicy())  # no known_hosts error
    # sshcon.connect(hostname, username=myuser,
    #                key_filename=mySSHK)  # no passwd needed

    # channel = sshcon.invoke_shell()
    # send_data = channel.recv(9999)
    # print("Connected")

    # channel.send('sudo su - p1c1m1054\n')
    # channel.send('cd /opt/app/p1c1m1054/NECA4/Neca_activity\n')
    # channel.send('./main.ksh\n')

    # while not channel.recv_ready():
    #     time.sleep(5)

    # receive_data = channel.recv(9999)

    # res_data = receive_data.decode("ascii")
    # channel.send('exit\n')
    # channel.send('exit\n')

    # sshcon.close()

    # ********************* end of main.ksh *******************************

    # ssh = paramiko.SSHClient()
    # ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    # ssh.connect(hostname='130.5.126.18', username=ATT_ID,
    #             key_filename=PPK_Path, port=22)

    # sftp_client = ssh.open_sftp()
    # remote_file = sftp_client.open('/opt/app/p1c1m1054/NECA4/db_load.log')

    # try:
    #     for line in remote_file:
    #         if line.startswith('WOS NECA activity completed succesfully'):
    #             print('main.ksh Script executed successfully...')
    #         else:
    #             print('main.ksh Script failed...please check')
    #             sys.exit()
    # finally:
    #     remote_file.close()

    # sftp_client.close()
    # ssh.close()

    date = str(
        input("Once main.ksh is completed, Please enter IST date in YYYYMMDD format:\n"))
    csvFile = (date + '.neca4.csv')
    # 20200501.neca4.csv
    # print(csvFile)
    tmp1 = environ.get('TEMP')
    tmp = tmp1.replace('\\', '\\\\')
    tmp = tmp.replace('\\', '\\')
    # print(tmp)

    print("Downloading "+csvFile + " on your machine at " + tmp1)
    ssh = paramiko.SSHClient()
    ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    ssh.connect(hostname='130.5.126.18', username=ATT_ID,
                key_filename=PPK_Path, port=22)
    sftp_client = ssh.open_sftp()
    sftp_client.get('/opt/app/p1c1m1054/NECA4/' + csvFile,
                    tmp + '\\' + csvFile)
    sftp_client.close()
    ssh.close()
    print(csvFile + " file downloaded successfully on your machine.")


# ****************************** Start of transfer to dev server *****************************************

    print("Sending " + csvFile + " to development 135.213.95.201 server...")

    ssh = paramiko.SSHClient()
    ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    ssh.connect(hostname='135.213.95.201', username=ATT_ID,
                key_filename=PPK_Path, port=22)
    sftp_client = ssh.open_sftp()
    sftp_client.put(tmp + '\\' + csvFile,
                    '/tmp/' + csvFile)
    sftp_client.close()
    ssh.exec_command('chmod 777 /tmp/' + csvFile)
    ssh.close()
    print(csvFile + " file copied successfully on dev 135.213.95.201 server in /tmp dir")

# ****************************** End of transfer to dev server *******************************************

else:
    print("File count is not 24, some files are missing. Please check...")
